﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace UTS_PBO
{
    public partial class Halaman_Inventaris : Form
    {
        private string connectionString = "Host=localhost;Username=postgres;Password=M#Anb8nb;Database=PBO";

        public Halaman_Inventaris()
        {
            InitializeComponent();
            this.button1.Click += new System.EventHandler(this.button1_Click);

            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void LoadData()
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM inventoris";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        dataAdapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

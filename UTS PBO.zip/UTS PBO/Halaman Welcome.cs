using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UTS_PBO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void buttonINVENTARIS_Click(object sender, EventArgs e)
        {
            Halaman_Inventaris halaman_inventaris = new Halaman_Inventaris();
            halaman_inventaris.Show();
            this.Hide();
        }

        private void buttonPENDAFTARAN_Click(object sender, EventArgs e)
        {
            Halaman_Daftar halaman_Daftar = new Halaman_Daftar();
            halaman_Daftar.Show();
            this.Hide();
        }
        private void buttonLOGIN_Click(object sender, EventArgs e)
        {
            Halaman_Login halaman_Login = new Halaman_Login();
            halaman_Login.Show();
            this.Hide();
        }

    }
}

﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace UTS_PBO
{
    public partial class Halaman_Login : Form
    {
        private string connectionString = "Host=localhost;Username=postgres;Password=M#Anb8nb;Database=PBO";

        public Halaman_Login()
        {
            InitializeComponent();
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.buttonMASUK.Click += new System.EventHandler(this.buttonMASUK_Click);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void buttonMASUK_Click(object sender, EventArgs e)
        {
            string username = textBoxUSERNAME.Text.Trim();
            string password = textBoxPASSWORD.Text.Trim();

            if (ValidateLogin(username, password))
            {
                MessageBox.Show("Login berhasil!", "Login Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Halaman_Dashboard_Admin halaman_Dashboard_Admin = new Halaman_Dashboard_Admin();
                halaman_Dashboard_Admin.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username atau password salah!", "Login Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateLogin(string username, string password)
        {
            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM users WHERE nama = @username AND password = @password";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", password);
                        int result = Convert.ToInt32(command.ExecuteScalar());
                        return result > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }
}

﻿namespace UTS_PBO
{
    partial class Halaman_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            textBoxUSERNAME = new TextBox();
            textBoxPASSWORD = new TextBox();
            buttonMASUK = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(954, 604);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 0;
            button1.Text = "Kembali";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(153, 64);
            label1.Name = "label1";
            label1.Size = new Size(77, 32);
            label1.TabIndex = 1;
            label1.Text = "Nama";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(153, 185);
            label2.Name = "label2";
            label2.Size = new Size(111, 32);
            label2.TabIndex = 2;
            label2.Text = "Password";
            // 
            // textBoxUSERNAME
            // 
            textBoxUSERNAME.Location = new Point(157, 119);
            textBoxUSERNAME.Name = "textBoxUSERNAME";
            textBoxUSERNAME.Size = new Size(150, 31);
            textBoxUSERNAME.TabIndex = 3;
            // 
            // textBoxPASSWORD
            // 
            textBoxPASSWORD.Location = new Point(153, 265);
            textBoxPASSWORD.Name = "textBoxPASSWORD";
            textBoxPASSWORD.Size = new Size(150, 31);
            textBoxPASSWORD.TabIndex = 4;
            // 
            // buttonMASUK
            // 
            buttonMASUK.Location = new Point(469, 358);
            buttonMASUK.Name = "buttonMASUK";
            buttonMASUK.Size = new Size(207, 47);
            buttonMASUK.TabIndex = 5;
            buttonMASUK.Text = "Masuk";
            buttonMASUK.UseVisualStyleBackColor = true;
            buttonMASUK.Click += buttonMASUK_Click;
            // 
            // Halaman_Login
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1107, 677);
            Controls.Add(buttonMASUK);
            Controls.Add(textBoxPASSWORD);
            Controls.Add(textBoxUSERNAME);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Name = "Halaman_Login";
            Text = "Halaman_Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Label label2;
        private TextBox textBoxUSERNAME;
        private TextBox textBoxPASSWORD;
        private Button buttonMASUK;
    }
}